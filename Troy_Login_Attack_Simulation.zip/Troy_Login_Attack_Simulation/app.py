from flask import Flask, render_template, request
from datetime import datetime
import os

app = Flask(__name__)

LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "auth.log")

os.makedirs(LOG_DIR, exist_ok=True)

VALID_USERNAME = "bankuser"
VALID_PASSWORD = "SecurePass123"


def write_log(username, ip, status, reason):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    log_entry = (
        f"{timestamp} | IP={ip} | USER={username} | "
        f"STATUS={status} | REASON={reason}\n"
    )

    with open(LOG_FILE, "a") as file:
        file.write(log_entry)


@app.route("/", methods=["GET", "POST"])
def login():
    message = ""

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        ip = request.remote_addr

        if username == VALID_USERNAME and password == VALID_PASSWORD:
            write_log(username, ip, "SUCCESS", "Valid login")
            message = "Login successful. Welcome to CPP Bank."
        else:
            write_log(username, ip, "FAILED", "Invalid username or password")
            message = "Login failed. Invalid username or password."

    return render_template("login.html", message=message)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
